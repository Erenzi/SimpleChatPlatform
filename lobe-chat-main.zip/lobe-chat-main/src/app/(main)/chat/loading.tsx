import CircleLoading from '@/components/CircleLoading';

export default () => <CircleLoading />;

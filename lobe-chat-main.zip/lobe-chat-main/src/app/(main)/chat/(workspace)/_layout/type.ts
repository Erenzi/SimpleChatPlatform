import { ReactNode } from 'react';

export interface LayoutProps {
  children: ReactNode;
  conversation: ReactNode;
  portal: ReactNode;
  topic: ReactNode;
}

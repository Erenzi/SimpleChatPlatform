import { ReactNode } from 'react';

export interface LayoutProps {
  children: ReactNode;
  session: ReactNode;
}

import SkeletonLoading from '@/components/SkeletonLoading';

export default () => {
  return <SkeletonLoading paragraph={{ rows: 8 }} />;
};

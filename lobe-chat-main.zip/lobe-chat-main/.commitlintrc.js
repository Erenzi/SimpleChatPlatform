module.exports = require('@lobehub/lint').commitlint;

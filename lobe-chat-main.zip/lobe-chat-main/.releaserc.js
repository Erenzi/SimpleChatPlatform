module.exports = require('@lobehub/lint').semanticRelease;
